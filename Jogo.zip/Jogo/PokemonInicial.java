package Jogo;

class PokemonInicial extends Pokemon {

    public PokemonInicial(String nome, int vida, String tipo, String fraqueza, String eficacia, int ataque, int ataqueEspecial, int velocidade) {
        super(nome, vida, tipo, fraqueza, eficacia, ataque, ataqueEspecial, velocidade);
    }

    public void aumentarAtaque(int aumento) {
        ataque += aumento;
        ataqueEspecial += aumento;
    }

    public void aumentarAtaque(int aumentoAtaque, int aumentoEspecial) {
        ataque += aumentoAtaque;
        ataqueEspecial += aumentoEspecial;
    }

    @Override
    public void mostrarCategoria() {
        System.out.println(getNome() + " é um Pokémon inicial.");
    }
}