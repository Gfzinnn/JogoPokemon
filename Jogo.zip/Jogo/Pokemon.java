package Jogo;

import static Jogo.Pokemons.*;

import java.util.*;

public class Pokemon {

    public static final Scanner teclado = new Scanner(System.in);

    private String nome;
    private int vida;
    private int vidaAtual;
    protected int ataque;
    protected int ataqueEspecial;
    protected int velocidade;
    String tipo;
    String fraqueza;
    String eficacia;
    protected int exp;

    public Pokemon(String nome, int vida, String tipo, String fraqueza, String eficacia, int ataque, int ataqueEspecial, int velocidade) {
        setNome(nome);
        setVida(vida);
        setVidaAtual(vida);
        this.ataque = ataque;
        this.ataqueEspecial = ataqueEspecial;
        this.tipo = tipo;
        this.fraqueza = fraqueza;
        this.eficacia = eficacia;
        this.exp = 0;
        this.velocidade = velocidade;
    }
    public void evoluir() {
        Evolucoes.evoluir(this);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            System.out.println("Nome inválido!");
            return;
        }

        this.nome = nome;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        if (vida <= 0) {
            System.out.println("A vida deve ser maior que 0!");
            return;
        }

        this.vida = vida;

        if (this.vidaAtual > vida) {
            this.vidaAtual = vida;
        }
    }

    public int getVidaAtual() {
        return vidaAtual;
    }

    public void setVidaAtual(int vidaAtual) {
        if (vidaAtual < 0) {
            this.vidaAtual = 0;
        } else if (vidaAtual > this.vida) {
            this.vidaAtual = this.vida;
        } else {
            this.vidaAtual = vidaAtual;
        }
    }

    public void mostrarCategoria() {
        System.out.println(getNome() + " é um Pokémon.");
    }

    public static void tempo() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        Random random = new Random();

        int escolha;
        int confirmarEscolha;
        int continuar_jogo = 1;
        Pokemon escolhido = null;

        while (continuar_jogo == 1) {

            escolhido = null;

            System.out.println(
                    "\nEscolha sua geração: \n1 - Primeira Geração\n2 - Segunda Geração\n3 - Terceira Geração\n4 - Sair\nOpção: "
            );

            int geracao = teclado.nextInt();

            while (escolhido == null) {

                if (geracao == 1) {

                    System.out.print(
                            "\n======= PRIMEIRA GERAÇÃO ======="
                            + "\nEscolha entre: \n1 - Charmander\n2 - Bulbassaur\n3 - Squirtle\nOpção: "
                    );

                    escolha = teclado.nextInt();

                    while (escolha > 3 || escolha < 1) {
                        System.out.println("Valor inválido! Tente novamente");

                        System.out.print(
                                "Escolha entre: \n1 - Charmander\n2 - Bulbassaur\n3 - Squirtle\nOpção: "
                        );

                        escolha = teclado.nextInt();
                    }

                    if (escolha == 1) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p3.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p3.getNome()
                                + "\nVida: " + p3.getVida()
                                + "\nTipo: " + p3.tipo
                                + "\nAtaque: " + p3.ataque
                                + "\nAtaque Especial: " + p3.ataqueEspecial
                                + "\nVelocidade: " + p3.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p3;
                        }

                    } else if (escolha == 2) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p6.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p6.getNome()
                                + "\nVida: " + p6.getVida()
                                + "\nTipo: " + p6.tipo
                                + "\nAtaque: " + p6.ataque
                                + "\nAtaque Especial: " + p6.ataqueEspecial
                                + "\nVelocidade: " + p6.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p6;
                        }

                    } else if (escolha == 3) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p9.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p9.getNome()
                                + "\nVida: " + p9.getVida()
                                + "\nTipo: " + p9.tipo
                                + "\nAtaque: " + p9.ataque
                                + "\nAtaque Especial: " + p9.ataqueEspecial
                                + "\nVelocidade: " + p9.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p9;
                        }
                    }

                } else if (geracao == 2) {

                    System.out.print(
                            "\n======= SEGUNDA GERAÇÃO ======="
                            + "\nEscolha entre: \n1 - Cyndaquil\n2 - Chikorita\n3 - Totodile\nOpção: "
                    );

                    escolha = teclado.nextInt();

                    while (escolha > 3 || escolha < 1) {
                        System.out.println("Valor inválido! Tente novamente");

                        System.out.print(
                                "Escolha entre: \n1 - Cyndaquil\n2 - Chikorita\n3 - Totodile\nOpção: "
                        );

                        escolha = teclado.nextInt();
                    }

                    if (escolha == 1) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p15.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p15.getNome()
                                + "\nVida: " + p15.getVida()
                                + "\nTipo: " + p15.tipo
                                + "\nAtaque: " + p15.ataque
                                + "\nAtaque Especial: " + p15.ataqueEspecial
                                + "\nVelocidade: " + p15.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p15;
                        }

                    } else if (escolha == 2) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p12.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p12.getNome()
                                + "\nVida: " + p12.getVida()
                                + "\nTipo: " + p12.tipo
                                + "\nAtaque: " + p12.ataque
                                + "\nAtaque Especial: " + p12.ataqueEspecial
                                + "\nVelocidade: " + p12.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p12;
                        }

                    } else if (escolha == 3) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p18.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p18.getNome()
                                + "\nVida: " + p18.getVida()
                                + "\nTipo: " + p18.tipo
                                + "\nAtaque: " + p18.ataque
                                + "\nAtaque Especial: " + p18.ataqueEspecial
                                + "\nVelocidade: " + p18.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p18;
                        }
                    }

                } else if (geracao == 3) {

                    System.out.print(
                            "\n======= TERCEIRA GERAÇÃO ======="
                            + "\nEscolha entre: \n1 - Torchic\n2 - Treecko\n3 - Mudkip\nOpção: "
                    );

                    escolha = teclado.nextInt();

                    while (escolha > 3 || escolha < 1) {
                        System.out.println("Valor inválido! Tente novamente");

                        System.out.print(
                                "Escolha entre: \n1 - Torchic\n2 - Treecko\n3 - Mudkip\nOpção: "
                        );

                        escolha = teclado.nextInt();
                    }

                    if (escolha == 1) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p24.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p24.getNome()
                                + "\nVida: " + p24.getVida()
                                + "\nTipo: " + p24.tipo
                                + "\nAtaque: " + p24.ataque
                                + "\nAtaque Especial: " + p24.ataqueEspecial
                                + "\nVelocidade: " + p24.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p24;
                        }

                    } else if (escolha == 2) {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p21.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p21.getNome()
                                + "\nVida: " + p21.getVida()
                                + "\nTipo: " + p21.tipo
                                + "\nAtaque: " + p21.ataque
                                + "\nAtaque Especial: " + p21.ataqueEspecial
                                + "\nVelocidade: " + p21.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p21;
                        }

                    } else {

                        tempo();

                        System.out.println("\nVocê escolheu o " + p27.getNome());

                        tempo();

                        System.out.println(
                                "\n=====INFORMAÇÕES=====\nNome: " + p27.getNome()
                                + "\nVida: " + p27.getVida()
                                + "\nTipo: " + p27.tipo
                                + "\nAtaque: " + p27.ataque
                                + "\nAtaque Especial: " + p27.ataqueEspecial
                                + "\nVelocidade: " + p27.velocidade
                        );

                        tempo();

                        System.out.println("\nConfirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                        confirmarEscolha = teclado.nextInt();

                        while (confirmarEscolha > 2 || confirmarEscolha < 1) {
                            System.out.println("Valor inválido! Tente novamente");
                            System.out.println("Confirmar escolha? \n1 - SIM\n2 - NÃO\nOpção: ");
                            confirmarEscolha = teclado.nextInt();
                        }

                        if (confirmarEscolha == 1) {
                            escolhido = p27;
                        }
                    }

                } else {
                    break;
                }
            }

            if (escolhido != null) {
                escolhido.setVidaAtual(escolhido.getVida());
            }

            Pokemon inimigo = pokemons1.get(random.nextInt(pokemons1.size()));
            int quantidadeBatalha = 0;
            int escolhaContinuar = 1;

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("\n======= MUNDO 1 =======");
            System.out.println("Pokémons que você poderá enfrentar:");

            for (Pokemon pokemon : pokemons1) {
                if (!pokemon.getNome().equals(escolhido.getNome())) {
                    System.out.println("- " + pokemon.getNome());
                }
            }
            System.out.println("- Darkrai (CHEFÃO)");

            try {
                Thread.sleep(2500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            while (escolhaContinuar == 1) {

                if (quantidadeBatalha == 6) {

                    System.out.println("\n======= MUNDO 2 =======");
                    System.out.println("Pokémons que você poderá enfrentar:");

                    for (Pokemon pokemon : pokemons2) {
                        if (!pokemon.getNome().equals(escolhido.getNome())) {
                            System.out.println("- " + pokemon.getNome());
                        }
                    }

                    System.out.println("- Mewtwo (CHEFÃO)");
                }
                if (quantidadeBatalha == 12) {

                    System.out.println("\n======= MUNDO 3 =======");
                    System.out.println("Pokémons que você poderá enfrentar:");

                    for (Pokemon pokemon : pokemons3) {
                        if (!pokemon.getNome().equals(escolhido.getNome())) {
                            System.out.println("- " + pokemon.getNome());
                        }
                    }

                    System.out.println("- Arceus (CHEFÃO)");
                }

                quantidadeBatalha += 1;

                if (quantidadeBatalha <= 5) {
                    inimigo = pokemons1.get(random.nextInt(pokemons1.size()));
                } else if (quantidadeBatalha == 6) {
                    System.out.println("\nALERTA: UM CHEFÃO APARECEU! ");
                    inimigo = pokemons4.get(0);
                } else if (quantidadeBatalha >= 7 && quantidadeBatalha <= 11) {
                    inimigo = pokemons2.get(random.nextInt(pokemons2.size()));
                } else if (quantidadeBatalha == 12) {
                    System.out.println("\nALERTA: CHEFÃO FINAL DO SEGUNDO MUNDO! ");
                    inimigo = pokemons4.get(1);
                } else if (quantidadeBatalha >= 13 && quantidadeBatalha <= 17) {
                    inimigo = pokemons3.get(random.nextInt(pokemons3.size()));
                } else if (quantidadeBatalha == 18) {
                    System.out.println("\nALERTA: CHEFÃO SUPREMO! ");
                    inimigo = pokemons4.get(2);
                }

                while (inimigo == escolhido) {

                    if (quantidadeBatalha <= 5) {
                        inimigo = pokemons1.get(random.nextInt(pokemons1.size()));
                    } else if (quantidadeBatalha >= 7 && quantidadeBatalha <= 11) {
                        inimigo = pokemons2.get(random.nextInt(pokemons2.size()));
                    } else if (quantidadeBatalha >= 13 && quantidadeBatalha <= 17) {
                        inimigo = pokemons3.get(random.nextInt(pokemons3.size()));
                    }
                }

                inimigo.setVidaAtual(inimigo.getVida());

                System.out.println("\n" + quantidadeBatalha + "ª BATALHA");

                Batalha.batalha(escolhido, inimigo);

                if (escolhido.getVidaAtual() > 0) {
                    System.out.println("Deseja continuar? \n1 - SIM\n2 - NÃO\nOpção: ");
                    escolhaContinuar = teclado.nextInt();
                }

                if (escolhaContinuar == 2) {
                    System.out.println(
                            "\nVocê decidiu parar!\nTotal de lutas: " + quantidadeBatalha
                    );

                    continuar_jogo = 2;
                    break;
                }

                if (escolhido.getVidaAtual() <= 0) {

                    System.out.println(
                            "\n=======VOCÊ PERDEU=======\n"
                            + inimigo.getNome()
                            + " derrotou você!\nTotal de lutas: "
                            + quantidadeBatalha
                    );

                    System.out.println(
                            "\nDeseja recomeçar? \n1 - SIM\n2 - NÃO\nOpção: "
                    );

                    continuar_jogo = teclado.nextInt();

                    if (continuar_jogo == 1) {
                        break;
                    } else {
                        break;
                    }
                }

                if (quantidadeBatalha > 18) {
                    System.out.println(
                            "\n=======PARABÉNS=======\nVocê derrotou o Arceus e zerou o jogo!"
                    );

                    continuar_jogo = 2;
                    break;
                }
            }
        }
    }
}
