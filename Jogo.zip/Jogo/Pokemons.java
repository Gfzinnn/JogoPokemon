package Jogo;

import java.util.*;

public class Pokemons {

    public static Pokemon p1 = new Pokemon("Pikachu", 70, "Eletrico", "Terra", "Água", 30, 40, 90);
    public static Pokemon p2 = new Pokemon("Raichu", 120, "Eletrico", "Terra", "Água", 50, 60, 110);

    public static PokemonInicial p3 = new PokemonInicial("Charmander", 80, "Fogo", "Água", "Planta", 30, 40, 65);
    public static Pokemon p4 = new Pokemon("Charmeleon", 120, "Fogo", "Água", "Planta", 40, 50, 80);
    public static Pokemon p5 = new Pokemon("Charizard", 160, "Fogo", "Água", "Planta", 50, 70, 100);

    public static PokemonInicial p6 = new PokemonInicial("Bulbasaur", 90, "Planta", "Fogo", "Pedra", 35, 45, 45);
    public static Pokemon p7 = new Pokemon("Ivysaur", 120, "Planta", "Fogo", "Pedra", 40, 50, 60);
    public static Pokemon p8 = new Pokemon("Venusaur", 160, "Planta", "Fogo", "Pedra", 50, 60, 80);

    public static PokemonInicial p9 = new PokemonInicial("Squirtle", 90, "Água", "Planta", "Fogo", 35, 35, 43);
    public static Pokemon p10 = new Pokemon("Wartortle", 120, "Água", "Planta", "Fogo", 40, 50, 58);
    public static Pokemon p11 = new Pokemon("Blastoise", 160, "Água", "Planta", "Fogo", 50, 60, 78);

    public static PokemonInicial p12 = new PokemonInicial("Chikorita", 90, "Planta", "Fogo", "Água", 35, 35, 45);
    public static Pokemon p13 = new Pokemon("Bayleef", 120, "Planta", "Fogo", "Água", 40, 50, 60);
    public static Pokemon p14 = new Pokemon("Meganium", 160, "Planta", "Fogo", "Água", 50, 60, 80);

    public static PokemonInicial p15 = new PokemonInicial("Cyndaquil", 60, "Fogo", "Água", "Planta", 35, 45, 65);
    public static Pokemon p16 = new Pokemon("Quilava", 90, "Fogo", "Água", "Planta", 40, 50, 80);
    public static Pokemon p17 = new Pokemon("Typhlosion", 120, "Fogo", "Água", "Planta", 50, 70, 100);

    public static PokemonInicial p18 = new PokemonInicial("Totodile", 90, "Água", "Planta", "Fogo", 30, 40, 43);
    public static Pokemon p19 = new Pokemon("Croconaw", 120, "Água", "Planta", "Fogo", 40, 50, 58);
    public static Pokemon p20 = new Pokemon("Feraligatr", 160, "Água", "Planta", "Fogo", 50, 60, 78);

    public static PokemonInicial p21 = new PokemonInicial("Treecko", 90, "Planta", "Fogo", "Água", 35, 45, 70);
    public static Pokemon p22 = new Pokemon("Grovyle", 120, "Planta", "Fogo", "Água", 45, 55, 95);
    public static Pokemon p23 = new Pokemon("Sceptile", 160, "Planta", "Fogo", "Água", 55, 65, 120);

    public static PokemonInicial p24 = new PokemonInicial("Torchic", 80, "Fogo", "Água", "Planta", 35, 45, 45);
    public static Pokemon p25 = new Pokemon("Combusken", 120, "Fogo", "Água", "Planta", 40, 50, 55);
    public static Pokemon p26 = new Pokemon("Blaziken", 160, "Fogo", "Água", "Planta", 60, 70, 80);

    public static PokemonInicial p27 = new PokemonInicial("Mudkip", 90, "Água", "Planta", "Fogo", 35, 45, 40);
    public static Pokemon p28 = new Pokemon("Marshtomp", 120, "Água/Terra", "Planta", "Fogo", 40, 55, 50);
    public static Pokemon p29 = new Pokemon("Swampert", 160, "Água/Terra", "Planta", "Fogo", 65, 70, 60);

    public static Pokemon p30 = new Pokemon("Tinkatink", 120, "Aço", "Fogo", "Pedra", 25, 35, 58);
    public static Pokemon p31 = new Pokemon("Tinkatuff", 160, "Aço", "Fogo", "Pedra", 40, 50, 78);
    public static Pokemon p32 = new Pokemon("Tinkaton", 180, "Aço", "Fogo", "Pedra", 45, 55, 94);

    public static Pokemon p33 = new Pokemon("Riolu", 80, "Lutador", "Psiquico", "Normal", 30, 40, 60);
    public static Pokemon p34 = new Pokemon("Lucario", 140, "Lutador", "Psiquico", "Normal", 65, 75, 90);

    public static PokemonLendario p35 = new PokemonLendario("Darkrai", 150, "Sombrio", "Lutador", "Psiquico", 55, 70, 125);
    public static PokemonLendario p36 = new PokemonLendario("Mewtwo", 210, "Psiquico", "Sombrio", "Lutador", 65, 80, 130);
    public static PokemonLendario p37 = new PokemonLendario("Arceus", 240, "Normal", "Lutador", " ", 70, 80, 120);


    public static ArrayList<Pokemon> pokemons1 = new ArrayList<>();
    public static ArrayList<Pokemon> pokemons2 = new ArrayList<>();
    public static ArrayList<Pokemon> pokemons3 = new ArrayList<>();
    public static ArrayList<Pokemon> pokemons4 = new ArrayList<>();


    static {

        Collections.addAll(
            pokemons1,
            p3, p6, p9, p12, p15, p18, p21, p24, p27
        );

        Collections.addAll(
            pokemons2,
            p4, p7, p10, p13, p16, p19, p22, p25, p28
        );

        Collections.addAll(
            pokemons3,
            p5, p8, p11, p14, p17, p20, p23, p26, p29
        );

        Collections.addAll(
            pokemons4,
            p35, p36, p37
        );
    }
}