package Jogo;

class PokemonLendario extends Pokemon {

    public PokemonLendario(String nome, int vida, String tipo, String fraqueza, String eficacia, int ataque, int ataqueEspecial, int velocidade) {
        super(nome, vida, tipo, fraqueza, eficacia, ataque, ataqueEspecial, velocidade);
    }

    @Override
    public void mostrarCategoria() {
        System.out.println(getNome() + " é um Pokémon lendário.");
    }

}