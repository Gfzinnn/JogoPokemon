package Jogo;

public class Evolucoes {

    public static void evoluir(Pokemon pokemon) {

        if (pokemon instanceof PokemonInicial) {

            PokemonInicial inicial = (PokemonInicial) pokemon;

            if (pokemon.getNome().equals("Charmander") && pokemon.exp >= 100) {
                pokemon.setNome("Charmeleon");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 80;
                System.out.println("\n✨ O seu Charmander evoluiu para CHARMELEON!\n");

            } else if (pokemon.getNome().equals("Charmeleon") && pokemon.exp >= 250) {
                pokemon.setNome("Charizard");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10, 20);
                pokemon.velocidade = 100;
                System.out.println("\n✨ O seu Charmeleon evoluiu para CHARIZARD!\n");

            } else if (pokemon.getNome().equals("Bulbasaur") && pokemon.exp >= 100) {
                pokemon.setNome("Ivysaur");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(5);
                pokemon.velocidade = 60;
                System.out.println("\n✨ O seu Bulbasaur evoluiu para IVYSAUR!\n");

            } else if (pokemon.getNome().equals("Ivysaur") && pokemon.exp >= 250) {
                pokemon.setNome("Venusaur");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 80;
                System.out.println("\n✨ O seu Ivysaur evoluiu para VENUSAUR!\n");

            } else if (pokemon.getNome().equals("Squirtle") && pokemon.exp >= 100) {
                pokemon.setNome("Wartortle");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(5, 15);
                pokemon.velocidade = 58;
                System.out.println("\n✨ O seu Squirtle evoluiu para WARTORTLE!\n");

            } else if (pokemon.getNome().equals("Wartortle") && pokemon.exp >= 250) {
                pokemon.setNome("Blastoise");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 78;
                System.out.println("\n✨ O seu Wartortle evoluiu para BLASTOISE!\n");

            } else if (pokemon.getNome().equals("Cyndaquil") && pokemon.exp >= 100) {
                pokemon.setNome("Quilava");
                pokemon.setVida(90);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(5);
                pokemon.velocidade = 80;
                System.out.println("\n✨ O seu Cyndaquil evoluiu para QUILAVA!\n");

            } else if (pokemon.getNome().equals("Quilava") && pokemon.exp >= 250) {
                pokemon.setNome("Typhlosion");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10, 20);
                pokemon.velocidade = 100;
                System.out.println("\n✨ O seu Quilava evoluiu para TYPHLOSION!\n");

            } else if (pokemon.getNome().equals("Chikorita") && pokemon.exp >= 100) {
                pokemon.setNome("Bayleef");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(5, 15);
                pokemon.velocidade = 60;
                System.out.println("\n✨ O seu Chikorita evoluiu para BAYLEEF!\n");

            } else if (pokemon.getNome().equals("Bayleef") && pokemon.exp >= 250) {
                pokemon.setNome("Meganium");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 80;
                System.out.println("\n✨ O seu Bayleef evoluiu para MEGANIUM!\n");

            } else if (pokemon.getNome().equals("Totodile") && pokemon.exp >= 100) {
                pokemon.setNome("Croconaw");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 58;
                System.out.println("\n✨ O seu Totodile evoluiu para CROCONAW!\n");

            } else if (pokemon.getNome().equals("Croconaw") && pokemon.exp >= 250) {
                pokemon.setNome("Feraligatr");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 78;
                System.out.println("\n✨ O seu Croconaw evoluiu para FERALIGATR!\n");

            } else if (pokemon.getNome().equals("Torchic") && pokemon.exp >= 100) {
                pokemon.setNome("Combusken");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(5);
                pokemon.velocidade = 55;
                System.out.println("\n✨ O seu Torchic evoluiu para COMBUSKEN!\n");

            } else if (pokemon.getNome().equals("Combusken") && pokemon.exp >= 250) {
                pokemon.setNome("Blaziken");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(20);
                pokemon.velocidade = 80;
                System.out.println("\n✨ O seu Combusken evoluiu para BLAZIKEN!\n");

            } else if (pokemon.getNome().equals("Treecko") && pokemon.exp >= 100) {
                pokemon.setNome("Grovyle");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 95;
                System.out.println("\n✨ O seu Treecko evoluiu para GROVYLE!\n");

            } else if (pokemon.getNome().equals("Grovyle") && pokemon.exp >= 250) {
                pokemon.setNome("Sceptile");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(10);
                pokemon.velocidade = 120;
                System.out.println("\n✨ O seu Grovyle evoluiu para SCEPTILE!\n");

            } else if (pokemon.getNome().equals("Mudkip") && pokemon.exp >= 100) {
                pokemon.setNome("Marshtomp");
                pokemon.setVida(120);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(5, 10);
                pokemon.velocidade = 50;
                System.out.println("\n✨ O seu Mudkip evoluiu para MARSHTOMP!\n");

            } else if (pokemon.getNome().equals("Marshtomp") && pokemon.exp >= 250) {
                pokemon.setNome("Swampert");
                pokemon.setVida(160);
                pokemon.setVidaAtual(pokemon.getVida());
                inicial.aumentarAtaque(25, 15);
                pokemon.velocidade = 60;
                System.out.println("\n✨ O seu Marshtomp evoluiu para SWAMPERT!\n");
            }
        }
    }
}