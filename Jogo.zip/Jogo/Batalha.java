package Jogo;

import java.util.Random;
import java.util.Scanner;

public class Batalha {

    private static final Scanner teclado = new Scanner(System.in);

    public static int ataqueJogador(Pokemon jogador, Pokemon inimigo) {
        System.out.println("1 - Ataque Normal\n2 - Ataque Especial\nOpção: ");
        int ataque = teclado.nextInt();

        while (ataque > 2 || ataque < 1) {
            System.out.println("Valor inválido! Digite novamente");
            System.out.println("1 - Ataque Normal\n2 - Ataque Especial\nOpção: ");
            ataque = teclado.nextInt();
        }

        int dano = 0;

        if (ataque == 2 && jogador.eficacia == inimigo.tipo) {
            System.out.println("\nVocê usou ataque especial em " + inimigo.getNome() + "! Seu ataque foi eficaz!");
            dano = (int) (jogador.ataqueEspecial * 1.30);
        } else if (ataque == 2 && jogador.eficacia != inimigo.tipo) {
            System.out.println("\nVocê usou ataque especial em " + inimigo.getNome() + "! Seu ataque não foi eficaz.");
            dano = (int) (jogador.ataqueEspecial * 0.70);
        } else if (ataque == 1) {
            System.out.println("\nVocê usou ataque em " + inimigo.getNome() + "!");
            dano = jogador.ataque;
        }

        inimigo.setVidaAtual(inimigo.getVidaAtual() - dano);

        System.out.println(jogador.getNome() + " causou " + dano + " de dano em " + inimigo.getNome() + "\n");

        return dano;
    }

    public static void defenderJogador(Pokemon jogador) {
        System.out.println(jogador.getNome() + " assumiu posição defensiva!\n");
    }

    public static int ataqueInimigo(Pokemon jogador,Pokemon inimigo,int ataqueInimigo,boolean defendendo) {
        int danoInimigo = 0;
        if (ataqueInimigo == 2 && jogador.fraqueza == inimigo.tipo) {
            System.out.println(inimigo.getNome() + " usou ataque especial! O ataque foi eficaz!");
            danoInimigo = (int) (inimigo.ataqueEspecial * 1.30);
        } else if (ataqueInimigo == 2 && jogador.fraqueza != inimigo.tipo) {
            System.out.println(inimigo.getNome() + " usou ataque especial! O ataque não foi eficaz.");
            danoInimigo = (int) (inimigo.ataqueEspecial * 0.70);
        } else if (ataqueInimigo == 1) {
            System.out.println(inimigo.getNome() + " usou ataque normal!");
            danoInimigo = inimigo.ataque;
        }

        if (defendendo) {
            System.out.println("(Defendido com sucesso! O dano foi reduzido)");
            danoInimigo -= 10;

            if (danoInimigo < 0) {
                danoInimigo = 0;
            }
        }

        jogador.setVidaAtual(jogador.getVidaAtual() - danoInimigo);

        System.out.println(inimigo.getNome() + " causou " + danoInimigo + " de dano em " + jogador.getNome() + "\n");

        return danoInimigo;
    }

    public static void batalha(Pokemon jogador, Pokemon inimigo) {
        Random random = new Random();
        int turno = 0;
        String condicao = "ganhou";

        while (jogador.getVidaAtual() > 0 && inimigo.getVidaAtual() > 0) {
            turno += 1;

            System.out.println("\n===== TURNO " + turno + " =====");
            System.out.println(jogador.getNome() + " (Vel: " + jogador.velocidade + "): \nVida: " + jogador.getVidaAtual() + "/" + jogador.getVida());
            System.out.println(inimigo.getNome() + " (Vel: " + inimigo.velocidade + "): \nVida: " + inimigo.getVidaAtual() + "/" + inimigo.getVida() + "\n");

            System.out.println("Escolha:\n1 - Atacar\n2 - Defender\nOpção: ");
            int escolhaBatalha = teclado.nextInt();

            while (escolhaBatalha < 1 || escolhaBatalha > 2) {
                System.out.println("Valor inválido! Digite novamente");
                System.out.println("Escolha:\n1 - Atacar\n2 - Defender\nOpção: ");
                escolhaBatalha = teclado.nextInt();
            }

            boolean defendendo = (escolhaBatalha == 2);
            int ataqueInimigo = random.nextInt(1, 3);

            if (jogador.velocidade >= inimigo.velocidade) {

                System.out.println("\n" + jogador.getNome() + " é mais rápido e age primeiro!");

                if (escolhaBatalha == 1) {
                    ataqueJogador(jogador, inimigo);

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                } else {
                    defenderJogador(jogador);

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                if (inimigo.getVidaAtual() <= 0) {
                    System.out.println("\n" + inimigo.getNome() + " foi derrotado!");
                    jogador.exp += 40;
                    jogador.evoluir();
                    jogador.setVidaAtual(jogador.getVida());
                    inimigo.setVidaAtual(inimigo.getVida());
                    condicao = "ganhou";

                    break;
                }

                System.out.println("Turno de contra-ataque de " + inimigo.getNome() + "\n");
                ataqueInimigo(jogador, inimigo, ataqueInimigo, defendendo);

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (jogador.getVidaAtual() <= 0) {
                    System.out.println("\n" + jogador.getNome() + " foi derrotado!");
                    condicao = "perdeu";
                    break;
                }

            } else {

                System.out.println("\n" + inimigo.getNome() + " é mais rápido e ataca primeiro!");

                ataqueInimigo(jogador, inimigo, ataqueInimigo, defendendo);

                if (jogador.getVidaAtual() <= 0) {
                    System.out.println("\n" + jogador.getNome() + " foi derrotado!");
                    condicao = "perdeu";
                    break;
                }

                if (escolhaBatalha == 1) {
                    System.out.println("Contra-ataque de " + jogador.getNome() + "\n");
                    ataqueJogador(jogador, inimigo);

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                } else {
                    System.out.println(jogador.getNome() + " usou a ação do turno para se defender.");
                }

                if (inimigo.getVidaAtual() <= 0) {
                    System.out.println("\n" + inimigo.getNome() + " foi derrotado!");
                    jogador.exp += 40;
                    jogador.evoluir();
                    jogador.setVidaAtual(jogador.getVida());
                    inimigo.setVidaAtual(inimigo.getVida());
                    condicao = "ganhou";

                    break;
                }
            }

            if (condicao == "perdeu") {
                break;
            }
        }
    }
}